#
# publish.ps1
#

Write-Verbose "Publishing complited"
